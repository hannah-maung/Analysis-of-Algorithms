Name: Hannah Maung
Assignment 3
language: c

How to run:

cd cs325
cd assignment3

running knapsack.cpp (problem1):
 
g++ knapsack.cpp
./a.out

running shopping.cpp (problem2):


g++ shopping.cpp
./.out

to check results:
vim results.txt to see output
