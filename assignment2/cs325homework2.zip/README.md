Language: c++

Running command:

go into cs325 server:
cd cs 325_homework2 

to run merge3.cpp:
g++ merge3.cpp
./a.out

to run merge3Time.cpp:
g++ merge3Time.cpp
./a.out


