Assignment 5:

Language: C++

Running command:
1. cd cs325
2. cd assignment5
3. g++ mst.cpp
4. ./a.out
