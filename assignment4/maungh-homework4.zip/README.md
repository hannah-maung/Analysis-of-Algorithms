
Name: Hannah Maung
Program: Homework 4
Language: c++


Directions:

cd cs325
cd assignment4
c++ sort.cpp
./a.out





