Directions:

go into cs325 server:
cd cs325

to run merge.cpp:
g++ merge.cpp
./a.out

to run insertion.cpp:
g++ insertion.cpp 
./a.out

to run mergeTime.cpp:
g++ mergeTime.cpp
./a.out

to run insertionTime.cpp
g++ insertionTime.cpp
./a.out
